package com.work.spring.data.jpa.practice.repository;

import com.work.spring.data.jpa.practice.entity.Course;
import com.work.spring.data.jpa.practice.entity.Teacher;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class TeacherRepositoryTest {

    @Autowired
    private TeacherRepository teacherRepository;

    @Test
    public void saveTeacher(){

        Course courseDBA = Course.builder()
                .title("DBA")
                .credits(5)
                .build();
        Course courseJAVA = Course.builder()
                .title("JAVA")
                .credits(6)
                .build();

        Teacher teacher =
                Teacher.builder()
                        .firstName("ZG")
                        .lastName("Young")
//                        .courses(List.of(courseDBA, courseJAVA))
                        .build();

        teacherRepository.save(teacher);
    }
}