package com.work.spring.data.jpa.practice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
