/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : localhost:3306
 Source Schema         : schooldb

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 07/12/2022 12:44:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course` (
  `course_id` bigint NOT NULL,
  `credits` int DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `teacher_id` bigint DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `FKsybhlxoejr4j3teomm5u2bx1n` (`teacher_id`),
  CONSTRAINT `FKsybhlxoejr4j3teomm5u2bx1n` FOREIGN KEY (`teacher_id`) REFERENCES `teacher` (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of course
-- ----------------------------
BEGIN;
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (1, 6, 'DSA', NULL);
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (2, 5, 'DBA', 1);
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (3, 6, 'JAVA', 1);
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (4, 6, '.net', NULL);
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (5, 6, 'Python', 2);
INSERT INTO `course` (`course_id`, `credits`, `title`, `teacher_id`) VALUES (7, 12, 'AI', 4);
COMMIT;

-- ----------------------------
-- Table structure for course_material
-- ----------------------------
DROP TABLE IF EXISTS `course_material`;
CREATE TABLE `course_material` (
  `course_material_id` bigint NOT NULL,
  `url` varchar(255) DEFAULT NULL,
  `course_id` bigint DEFAULT NULL,
  PRIMARY KEY (`course_material_id`),
  UNIQUE KEY `UK_h1og6srs8s1xhabgqtkhdf96q` (`course_id`),
  CONSTRAINT `FK6qgylrot7cxgungunwyrslpeo` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of course_material
-- ----------------------------
BEGIN;
INSERT INTO `course_material` (`course_material_id`, `url`, `course_id`) VALUES (4, 'www.google.com', 1);
INSERT INTO `course_material` (`course_material_id`, `url`, `course_id`) VALUES (6, 'www.baidu.com', 4);
COMMIT;

-- ----------------------------
-- Table structure for course_material_sequence
-- ----------------------------
DROP TABLE IF EXISTS `course_material_sequence`;
CREATE TABLE `course_material_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of course_material_sequence
-- ----------------------------
BEGIN;
INSERT INTO `course_material_sequence` (`next_val`) VALUES (7);
COMMIT;

-- ----------------------------
-- Table structure for course_sequence
-- ----------------------------
DROP TABLE IF EXISTS `course_sequence`;
CREATE TABLE `course_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of course_sequence
-- ----------------------------
BEGIN;
INSERT INTO `course_sequence` (`next_val`) VALUES (8);
COMMIT;

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `student_id` bigint NOT NULL,
  `email_id` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `guardian_email` varchar(255) DEFAULT NULL,
  `guardian_mobile` varchar(255) DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for student_course_map
-- ----------------------------
DROP TABLE IF EXISTS `student_course_map`;
CREATE TABLE `student_course_map` (
  `course_id` bigint NOT NULL,
  `student_id` bigint NOT NULL,
  KEY `FKhtofos1jo0mi02er8bqx62xrd` (`student_id`),
  KEY `FK4f31efg3l6lqa5n0yqml6h7c4` (`course_id`),
  CONSTRAINT `FK4f31efg3l6lqa5n0yqml6h7c4` FOREIGN KEY (`course_id`) REFERENCES `course` (`course_id`),
  CONSTRAINT `FKhtofos1jo0mi02er8bqx62xrd` FOREIGN KEY (`student_id`) REFERENCES `tbl_student` (`student_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student_course_map
-- ----------------------------
BEGIN;
INSERT INTO `student_course_map` (`course_id`, `student_id`) VALUES (7, 3);
COMMIT;

-- ----------------------------
-- Table structure for student_sequence
-- ----------------------------
DROP TABLE IF EXISTS `student_sequence`;
CREATE TABLE `student_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of student_sequence
-- ----------------------------
BEGIN;
INSERT INTO `student_sequence` (`next_val`) VALUES (4);
COMMIT;

-- ----------------------------
-- Table structure for tbl_student
-- ----------------------------
DROP TABLE IF EXISTS `tbl_student`;
CREATE TABLE `tbl_student` (
  `student_id` bigint NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `guardian_email` varchar(255) DEFAULT NULL,
  `guardian_mobile` varchar(255) DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `emailId_unique` (`email_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of tbl_student
-- ----------------------------
BEGIN;
INSERT INTO `tbl_student` (`student_id`, `email_address`, `first_name`, `guardian_email`, `guardian_mobile`, `guardian_name`, `last_name`) VALUES (1, 'jd@gmail.com', 'J', 'x@gmail.com', '1234567890', 'X', 'Z');
INSERT INTO `tbl_student` (`student_id`, `email_address`, `first_name`, `guardian_email`, `guardian_mobile`, `guardian_name`, `last_name`) VALUES (2, 'y@gmail.com', 'Y', 'x@gmail.com', '1234567890', 'X', 'Z');
INSERT INTO `tbl_student` (`student_id`, `email_address`, `first_name`, `guardian_email`, `guardian_mobile`, `guardian_name`, `last_name`) VALUES (3, 'm@gmail.com', 'Lazy', NULL, NULL, NULL, 'M');
COMMIT;

-- ----------------------------
-- Table structure for teacher
-- ----------------------------
DROP TABLE IF EXISTS `teacher`;
CREATE TABLE `teacher` (
  `teacher_id` bigint NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`teacher_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of teacher
-- ----------------------------
BEGIN;
INSERT INTO `teacher` (`teacher_id`, `first_name`, `last_name`) VALUES (1, 'ZG', 'Young');
INSERT INTO `teacher` (`teacher_id`, `first_name`, `last_name`) VALUES (2, 'X', 'Hu');
INSERT INTO `teacher` (`teacher_id`, `first_name`, `last_name`) VALUES (4, 'T', 'Lin');
COMMIT;

-- ----------------------------
-- Table structure for teacher_sequence
-- ----------------------------
DROP TABLE IF EXISTS `teacher_sequence`;
CREATE TABLE `teacher_sequence` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of teacher_sequence
-- ----------------------------
BEGIN;
INSERT INTO `teacher_sequence` (`next_val`) VALUES (5);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
